/**
 * HTMLメール機能を提供する。
 */
package please.change.me.common.mail.html;
