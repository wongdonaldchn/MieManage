/**
 * 拡張バリデーション機能を提供する。
 */
package please.change.me.core.validation.validator;

