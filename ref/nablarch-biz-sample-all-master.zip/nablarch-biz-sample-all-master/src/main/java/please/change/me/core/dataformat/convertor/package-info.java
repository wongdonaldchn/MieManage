/**
 * フレームワークが標準提供するコンバータ群の拡張機能を収めたパッケージ。
 */
package please.change.me.core.dataformat.convertor;
