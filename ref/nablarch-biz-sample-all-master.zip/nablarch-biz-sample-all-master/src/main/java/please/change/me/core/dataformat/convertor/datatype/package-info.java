/**
 * ファイルや電文のストリームを読み書きし、フィールドへの変換を行うデータタイプの拡張機能を収めたパッケージ。
 */
package please.change.me.core.dataformat.convertor.datatype;
