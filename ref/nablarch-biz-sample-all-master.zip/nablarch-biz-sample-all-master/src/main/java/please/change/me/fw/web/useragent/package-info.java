/**
 * User-Agentに関する機能を提供する。
 */
package please.change.me.fw.web.useragent;
