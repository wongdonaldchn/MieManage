/**
 * CAPTCHA認証機能を提供する。
 */
package please.change.me.common.captcha;
