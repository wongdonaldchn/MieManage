/**
 * 汎用データフォーマットの拡張機能を提供する。
 */
package please.change.me.core.dataformat;
